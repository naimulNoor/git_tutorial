import 'package:flutter/material.dart';
import 'package:untitled/widget/widget_iconbadge.dart';

import 'content_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin<HomePage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      bottomNavigationBar:  BottomNavigationBar(
        currentIndex: 0, // this will be set when a new tab is tapped
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.home),
            title: new Text('Home'),
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.qr_code_scanner),
            title: new Text('Scan'),
          ),
          BottomNavigationBarItem(
              icon: WidgetIconBadge(
                count: "3",
                icon: Icons.check,
                badgeColor: Colors.red,
                textColor: Colors.white,
              ),
              title: Text('Tasks')
          )
        ],
      ),
      body: ContentPage(),
    );
  }
}